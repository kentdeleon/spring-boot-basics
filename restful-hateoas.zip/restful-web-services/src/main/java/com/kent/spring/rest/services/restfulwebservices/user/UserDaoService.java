package com.kent.spring.rest.services.restfulwebservices.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class UserDaoService {

	private static List<UserVO> users = new ArrayList<>();

	private static int userCount = 3;

	static {
		users.add(new UserVO(1, "Adam", new Date()));
		users.add(new UserVO(2, "Eve", new Date()));
		users.add(new UserVO(3, "Jack", new Date()));
	}

	public List<UserVO> findAll() {
		return users;
	}

	public UserVO save(UserVO user) {
		if (user.getId() == null) {
			user.setId(++userCount);
		}
		users.add(user);

		return user;
	}

	public UserVO findOne(int id) {
		for (UserVO userVO : users) {
			if (userVO.getId().equals(id)) {
				return userVO;
			}

		}
		return null;
	}
	
	public UserVO deleteById(int id) {
		Iterator<UserVO> iterator = users.iterator();
		while(iterator.hasNext()) {
			UserVO user = iterator.next();
			if(user.getId().equals(id)) {
				iterator.remove();
				return user;
			}
		}
		return null;
	}
}
