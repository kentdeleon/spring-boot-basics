package com.kent.spring.rest.services.restfulwebservices.user;

import java.net.URI;
import java.util.List;

import javax.validation.Valid;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class UserResource {

	@Autowired
	private UserDaoService userDao;

	// retrieve all users
	@GetMapping(path = "/users")
	public List<UserVO> getAllUser() {
		return userDao.findAll();
	}

	/// retrieve users(int id)
	@GetMapping(path = "/users/{user_id}")
	public Resource<UserVO> getUser(@PathVariable int user_id) {
		UserVO user = userDao.findOne(user_id);

		if (user == null)
			throw new UserNotFoundException("id-" + user_id);
		//HATEOAS
		//Add spring-boot-starter-hateoas in pom xml
		//"all-users", SERVER_PATH + "/users"
		Resource<UserVO> resource = new Resource<UserVO>(user);
		
		ControllerLinkBuilder linkTo = linkTo(methodOn(this.getClass()).getAllUser());
		ControllerLinkBuilder linkToUser = linkTo(methodOn(this.getClass()).getUser(user_id));
		
		resource.add(linkTo.withRel("all-users"));
		resource.add(linkToUser.withRel("user-uri"));

		return resource;
	}



	// create a user
	@PostMapping(path = "/users")
	public ResponseEntity<UserVO> createUser(@Valid @RequestBody UserVO user) {
		UserVO savedUser = userDao.save(user);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedUser.getId())
				.toUri();

		return ResponseEntity.created(location).build();
	}

	// delete a user
	@DeleteMapping(path = "/users/{user_id}")
	public void deleteUserById(@PathVariable int user_id) {
		UserVO user = userDao.deleteById(user_id);

		if (user == null)
			throw new UserNotFoundException(String.format("id:%s not found, unable to delete", user_id));

	}
}
